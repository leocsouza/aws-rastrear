'use strict';

const { rastrearEncomendas } = require('correios-brasil');

module.exports.track = async event => {
    
    let  codRastreio = ['LB038399432HK']
    rastrearEncomendas(codRastreio).then((response) => {
           console.log("essa é a porra:")
           return{
            response: JSON.parse(response)
           } 
    });
    
};
